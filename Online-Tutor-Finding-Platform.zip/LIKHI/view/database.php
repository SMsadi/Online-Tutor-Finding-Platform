<?php
$host="localhost";
$user="root";
$pass="";
$dbname="todos";

$conn=mysqli_connect($host, $user, $pass, $dbname);



?>